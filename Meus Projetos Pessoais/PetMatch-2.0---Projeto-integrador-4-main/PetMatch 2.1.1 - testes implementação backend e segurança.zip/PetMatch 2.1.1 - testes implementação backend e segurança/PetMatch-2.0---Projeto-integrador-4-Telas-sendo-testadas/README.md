# PetMatch-2.0---Projeto-integrador-4
Repositório novo do projeto integrador

Foram feitas Modificações minimas nas telas principais, principalmente quanto a fontes e posicionamento de imagens, alem disso os testes de javascript já estão quase prontos para implementação completa, faltam serem feitos testes de segurança pois está sendo possivel fazer modificações por meio da url (utilizando de path traversal e javascript)
